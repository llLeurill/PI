﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JogadorInterage : MonoBehaviour
{


    public int EstaInteragindo = -1;
    public bool PodeExecutar = false;
    public bool escondido = false;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Esconderijo")
        {
            PodeExecutar = true;
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Esconderijo")
        {
            PodeExecutar = false;
            EstaInteragindo = -1;
        }
    }

    private void Update()
    {
        if (PodeExecutar == true)
        {
            if (Input.GetKeyDown(KeyCode.F))
            {
                EstaInteragindo = EstaInteragindo * (-1);  
                
                if(EstaInteragindo == 1)
                {
                    escondido = true;
                }
                else
                {
                    escondido = false;
                }
            }
        }
    }
}