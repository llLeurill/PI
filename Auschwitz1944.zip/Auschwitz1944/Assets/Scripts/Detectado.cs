﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Detectado : MonoBehaviour
{

    public GameObject Guarda;
    public bool JogadorDetectado;
    public bool Fugitivo = false;
    public bool JogadorEscapou;

    public void Update()
    {
        JogadorEscapou = Guarda.GetComponent<Inimigo>().Escapou;

        if (JogadorEscapou == true)
        {
            Fugitivo = false;
            JogadorEscapou = false;
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            JogadorDetectado = true;
            Fugitivo = false;
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player" && collision.gameObject.tag != "Chao")
        {
            JogadorDetectado = false;
            Fugitivo = true;
            Debug.Log("Objeto " + collision.gameObject.name + " saiu");
        }
    }
}