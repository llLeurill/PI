﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class Pause2 : MonoBehaviour {
    public Canvas pause;

    public void Retornar()
    {
        Time.timeScale = 1f;
        pause.enabled = false;
    }

    public void TentarNovamente()
    {
        SceneManager.LoadScene("Fase2");
        Time.timeScale = 1f;
    }

    public void Menu()
    {
        SceneManager.LoadScene("MENU");
        Time.timeScale = 1f;
    }
}
