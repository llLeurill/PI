﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inimigo : MonoBehaviour
{

    public Transform jogador;
    public GameObject inimigo;
    public GameObject Detector;
    public GameObject detectorParede;
    public Canvas gameOver;
    public LayerMask whatIsGround;
    private bool jogadorDetectado;
    public bool paredeDetectada;
    public bool JogadorFugitivo;
    public bool Detectou = false;
    public bool Escapou = false;
    bool isOnFloor = false;
    public float velocidade = 10f;
    public float movimento = 12f;
    public Rigidbody2D rbi;
    float TempoFugitivo = 3;
    SpriteRenderer sprite;

    private void Start()
    {
        sprite = GetComponent<SpriteRenderer>();

    }
    void Update()
    {
        paredeDetectada = detectorParede.GetComponent<DetectorParede>().ParedeDetectada;
        jogadorDetectado = Detector.GetComponent<Detectado>().JogadorDetectado;
        JogadorFugitivo = Detector.GetComponent<Detectado>().Fugitivo;
        Escapou = Detector.GetComponent<Detectado>().JogadorEscapou;
        float move = Input.GetAxis("Horizontal");

            if ((velocidade < 0 && sprite.flipX == true) || (velocidade > 0 && sprite.flipX == false))
        {
            Flip();
        }

            if (jogadorDetectado == true)
            {
                transform.position = Vector2.MoveTowards(transform.position, jogador.position, ((movimento + 3f) * Time.deltaTime));
                TempoFugitivo = 0.1f;
                GetComponent<Animator>().SetBool("avistando", true);
                GetComponent<Animator>().SetBool("procurando", false);
            }
            else
            {
                if (JogadorFugitivo == true)
                {
                    GetComponent<Animator>().SetBool("procurando", true);
                    GetComponent<Animator>().SetBool("avistando", false);
                    if (TempoFugitivo > 0)
                    {
                        TempoFugitivo -= Time.deltaTime;
                        Debug.Log("Procurando:" + (TempoFugitivo -= Time.deltaTime));

                        if (transform.position.x > jogador.transform.position.x)
                        {
                            velocidade = -10f;

                        }
                        else
                        {
                            velocidade = 10f;

                        }
                    }

                    if (TempoFugitivo <= 0)
                    {
                        Debug.Log("acabou o tempo");
                        GetComponent<Rigidbody2D>().velocity = new Vector2(velocidade, 0);
                    }

                }
                else
                {
                    GetComponent<Rigidbody2D>().velocity = new Vector2(velocidade, 0);
                }


                if (paredeDetectada == true)
                {
                    velocidade = velocidade * (-1f);
                    Escapou = true;
                    Detectou = true;
                    GetComponent<Animator>().SetBool("procurando", false);
                    GetComponent<Animator>().SetBool("avistando", false);
                }

                if (paredeDetectada == false)
                {
                    Detectou = false;
                }
            }
    }
    void Flip()
    {

        sprite.flipX = !sprite.flipX;
    }
}