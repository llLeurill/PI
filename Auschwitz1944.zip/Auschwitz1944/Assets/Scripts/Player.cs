﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.SceneManagement;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float speed = 10f;
    public float jumpForce = 200f;
    public LayerMask whatIsGround;
    public Canvas gameOver;
    public Canvas pause;
    bool isJumping = false;
   public bool isOnFloor = false;
    bool soltou = false;
    bool correndo = false;
    private float estamina = 10;
    private float tempoCansado = 10;
    private float tempoCansado2;
    private bool travar = false;
    public bool estaEscondido;
    public bool PodeSubir = false;
    private Rigidbody2D body;
    private bool Wdown;
    private bool Wup;
    public bool Fase2 = false;
    public int esc = -1;
    SpriteRenderer sprite;

    void Start()
    {
        body = GetComponent<Rigidbody2D>();
        sprite = GetComponent<SpriteRenderer>();
        body.constraints = RigidbodyConstraints2D.None | RigidbodyConstraints2D.FreezeRotation;
    }

    void Update()
    {
        estaEscondido = GetComponent<JogadorInterage>().escondido;
     
        if (Input.GetButtonDown("Jump") && isOnFloor == true)
            isJumping = true;

         Wdown = Input.GetKey(KeyCode.W);
         Wup = Input.GetKeyUp(KeyCode.W);

    }
    void FixedUpdate()
    {
        bool down = Input.GetKey(KeyCode.LeftShift);
        bool up = Input.GetKeyUp(KeyCode.LeftShift);

        float move = Input.GetAxis("Horizontal");

        body.velocity = new Vector2(move * speed, body.velocity.y);

        if ((move > 0 && sprite.flipX == true) || (move < 0 && sprite.flipX == false))
        {
            Flip();
        }

        if (down && soltou == false)
        {
            estamina -= Time.deltaTime;
            Debug.Log("Tempo Correndo:" + (estamina -= Time.deltaTime));
            if (estamina > 0)
            {
                if (move > 0)
                {
                    body.velocity = new Vector2(move * speed + (5), body.velocity.y);
                }
                else if (move < 0)
                {
                    body.velocity = new Vector2(move * speed - (5), body.velocity.y);
                }
            }
        }


        if (up && estamina > 0)
        {
            if (soltou == false)
                tempoCansado2 = 10 - estamina;

        }
        if (tempoCansado2 > 0)
        {
            soltou = true;
            tempoCansado2 -= Time.deltaTime;
            Debug.Log("Tempo Cansado2:" + (tempoCansado2 -= Time.deltaTime));
            body.velocity = new Vector2(move * speed, body.velocity.y);

            if (tempoCansado2 <= 0)
            {
                estamina = 10;
                Debug.Log("Máximo2");
                soltou = false;
            }
        }


        if (estamina <= 0)
        {
            soltou = true;
            tempoCansado -= Time.deltaTime;
            Debug.Log("Tempo Cansado:" + (tempoCansado -= Time.deltaTime));
            body.velocity = new Vector2(move * speed, body.velocity.y);

            if (tempoCansado <= 0)
            {
                estamina = 10;
                tempoCansado = 10;
                Debug.Log("Máximo");
                soltou = false;
            }
        }

        if (move > 0 || move < 0)
        {
            GetComponent<Animator>().SetBool("andando", true);

        }
        else
        {

            GetComponent<Animator>().SetBool("andando", false);


        }
        if (isJumping == true)
        {


            body.AddForce(new Vector2(0f, jumpForce));
            isJumping = false;
        }
        if (isOnFloor && isJumping == false)
        {
            GetComponent<Animator>().SetBool("pulando", false);
        }
        else
        {
            GetComponent<Animator>().SetBool("pulando", true);
            Debug.Log("Setou");
        }

        if(travar == true)
            Time.timeScale = 0f;


        if (Wdown)
            {
                if(PodeSubir == true)
                {
                    body.transform.Translate(0, 10 * Time.deltaTime, 0);
                    body.constraints = RigidbodyConstraints2D.FreezePositionY | RigidbodyConstraints2D.FreezeRotation;
                }
            }
            else if (Wup)
            {
                body.constraints = RigidbodyConstraints2D.None | RigidbodyConstraints2D.FreezeRotation;
                Debug.Log("Soltou o botao");
            }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            esc = esc * (-1);
            if(esc == 1)
            {
               
                pause.enabled = true;
            }else if(esc == -1)
            {
        
                pause.enabled = false;
            }
        }
    }

    void Flip()
    {

        sprite.flipX = !sprite.flipX;
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.gameObject.tag == "Objeto")
        {
            GetComponent<Animator>().SetBool("empurrando", true);
        }

        if (collision.gameObject.tag == "Subir")
        {
            PodeSubir = true;
        }

        if (collision.gameObject.tag == "Inimigo")
        {
            if (estaEscondido == false)
            {
                    travar = true;
                    gameOver.enabled = true;
                    Debug.Log("Encostou");
            }
        }

        if (collision.gameObject.tag == "InimigoEspecial")
        {
            if (estaEscondido == false)
            {
                SceneManager.LoadScene("Creditos");
            }
        }
    }

    public void OnTriggerExit2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "Subir")
        {
            PodeSubir = false;
            body.constraints = RigidbodyConstraints2D.None | RigidbodyConstraints2D.FreezeRotation;
        }

        if (collision.gameObject.tag == "Objeto")
        {
            GetComponent<Animator>().SetBool("empurrando", false);
        }
    }

    public void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Chao")
            isOnFloor = true;
    }

    public void OnCollisionExit2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Chao")
        isOnFloor = false;
    }
}