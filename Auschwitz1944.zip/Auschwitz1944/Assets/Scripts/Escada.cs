﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;




public class Escada : MonoBehaviour
{

    [SerializeField]
    private JogadorInterage jogadorInterage;
    [SerializeField]
    private UnityEvent botaoApertado;
    public GameObject Jogador;
   // public GameObject armario;
    public Rigidbody2D rb;
    public GameObject Subir;
    public bool PodeSubir;
   // public bool estaEscondido;

    private void Start()
    {
        rb = Jogador.GetComponent<Rigidbody2D>();

    }

    void Update()
    {
      //  estaEscondido = armario.GetComponent<InteragirComBotao>().escondido;
      //  PodeSubir = Subir.GetComponent<Subir>().subir;
        bool down = Input.GetKey(KeyCode.W);
        bool up = Input.GetKeyUp(KeyCode.W);

        if (PodeSubir == true)
        {
            if (down)
            {
              //  if(estaEscondido == false)
            //    {
                   // rb.transform.Translate(0, 10 * Time.deltaTime, 0);
                    //  rb.constraints = RigidbodyConstraints2D.FreezePositionY | RigidbodyConstraints2D.FreezeRotation;
              //  }
            }
            else if (up)
            {	
            //    if(estaEscondido == false)
             //   {
                  //  rb.constraints = RigidbodyConstraints2D.None | RigidbodyConstraints2D.FreezeRotation;
                 //   Debug.Log("Soltou o botao");
             //   }
                
            }
        }
        else if (PodeSubir == false)
        {
          // rb.constraints = RigidbodyConstraints2D.None | RigidbodyConstraints2D.FreezeRotation;
        }




    }
}