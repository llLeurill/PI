﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DetectorParede : MonoBehaviour
{
    public GameObject Guarda;
    public bool FoiDetectado = false;
    public bool ParedeDetectada = false;
    public float Tempo = 2;
    private void Update()
    {
        FoiDetectado = Guarda.GetComponent<Inimigo>().Detectou;

        if (FoiDetectado == true)
        {

            ParedeDetectada = false;
        }
    }


    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.tag == "Parede")
        {
            ParedeDetectada = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Parede")
        {
            ParedeDetectada = false;
        }
    }
}