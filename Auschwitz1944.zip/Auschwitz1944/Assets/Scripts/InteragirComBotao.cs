﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

[RequireComponent(typeof(Collider2D))]


public class InteragirComBotao : MonoBehaviour
{

    [SerializeField]
    private JogadorInterage jogadorInterage;
    [SerializeField]
    private UnityEvent botaoApertado;
    public GameObject Jogador;
    public Rigidbody2D rb;
    public bool inimigoVe;


    private void Start()
    {
        rb = Jogador.GetComponent<Rigidbody2D>();
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "VisaoInimigo")
        {
            inimigoVe = true;
        }
    }

    public void OnTriggerExit2D(Collider2D collision)
    {
        inimigoVe = false;
    }

    void Update()
    {
        if (jogadorInterage.PodeExecutar == true)
        {
            if (jogadorInterage.EstaInteragindo == 1)
            {
                if (inimigoVe == false)
                {
                    Jogador.GetComponent<Renderer>().enabled = false;
                    Jogador.GetComponent<Collider2D>().isTrigger = true;
                    rb.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezePositionY;
                    Jogador.tag = "Escondido";

                }
            }
            else
            {
                if (inimigoVe == true)
                {
                    Jogador.GetComponent<Renderer>().enabled = false;
                    Jogador.GetComponent<Collider2D>().isTrigger = false;
                    Jogador.GetComponent<Collider2D>().enabled = true;
                    rb.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezePositionY;
                    Jogador.tag = "Player";

                }
            }
            if (jogadorInterage.EstaInteragindo == -1)
            {
                Jogador.GetComponent<Renderer>().enabled = true;
                Jogador.GetComponent<Collider2D>().isTrigger = false;
                Jogador.GetComponent<Collider2D>().enabled = true;
                rb.constraints = RigidbodyConstraints2D.None | RigidbodyConstraints2D.FreezeRotation;
                Jogador.tag = "Player";

            }

        }
    }
}