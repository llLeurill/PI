﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOver1 : MonoBehaviour
{

    public void Fase1()
    {
        SceneManager.LoadScene("Fase1");
        Time.timeScale = 1f;
    }

    public void Menu()
    {
        SceneManager.LoadScene("MENU");
        Time.timeScale = 1f;
    }
}
