﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class GameOver2 : MonoBehaviour {

    public void Fase2()
    {
        SceneManager.LoadScene("Fase2");
        Time.timeScale = 1f;
    }

    public void Menu()
    {
        SceneManager.LoadScene("MENU");
        Time.timeScale = 1f;
    }
}
